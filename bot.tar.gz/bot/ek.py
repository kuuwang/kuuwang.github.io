import config
import irc.bot
import requests
import sys, re
import commands
import cmdlist
import openpyxl
import random
cmdlist = cmdlist.cmds


class TwitchBot(irc.bot.SingleServerIRCBot):


        def __init__(self, username, client_id, token, channel):


                self.client_id = client_id  
                self.token = token  

                self.channel = '#' + channel

                url = 'https://api.twitch.tv/kraken/users?login=' + channel  
                headers = {'Client-ID': client_id, 'Accept': 'application/vnd.twitchtv.v5+json'}  
                r = requests.get(url, headers=headers).json()  
                self.channel_id = r['users'][0]['_id']  

                server = 'irc.chat.twitch.tv'
                port = 6667
                print('서버 ' + server + ', 포트 ' + str(port) + '에 연결중...')
                irc.bot.SingleServerIRCBot.__init__(self, [(server, port, 'oauth:' + token)], username, username)  


        def on_welcome(self, c, e):
            
            
            print(self.channel + '에 연결되었습니다.')  

            c.cap('REQ', ':twitch.tv/membership')  
            c.cap('REQ', ':twitch.tv/tags')  
            c.cap('REQ', ':twitch.tv/commands')  
            c.join(self.channel)  

        def on_pubmsg(self, c, e):  
            # If a chat message starts with an exclamation point, try to run it as a command
            if e.arguments[0][:1] == '!':
                cmd = e.arguments[0][1:]
                self.do_command(e, cmd)
            return

        def do_command(self, e, cmd):
            
            c = self.connection
        
            cmd = cmd.split(' ')

            if cmd[0] in cmdlist["survival"]:
                c.privmsg(self.channel, commands.msgs.survival())
               
            if cmd[0] in cmdlist["title"]:
                c.privmsg(self.channel, commands.twitchAPI.title())
            if cmd[0] in cmdlist["game"]:
                c.privmsg(self.channel, commands.twitchAPI.game())
            if cmd[0] in cmdlist["uptime"]:
                c.privmsg(self.channel, commands.twitchAPI.uptime())
            if cmd[0] in cmdlist["choice"]:
                commands.rand.choice(self, e, cmd)
            if cmd[0] in cmdlist["dice"]:
                commands.rand.dice(self, e, cmd)
            if cmd[0] in cmdlist["time"]:
                c.privmsg(self.channel, commands.tz.do())
            if cmd[0] in cmdlist["cal"]:
                c.privmsg(self.channel, commands.cal.do(cmd))
            if cmd[0] in cmdlist["translate"]:
                commands.translate.translate(self, e, cmd)
            if cmd[0] in cmdlist["rag"]:
                commands.rand.rag(self, e, cmd)
            if cmd[0] in cmdlist["ragPromo"]:
                commands.rand.ragPromo(self, e, cmd)
            if cmd[0] in cmdlist["bin"]:
                commands.cal.transbin(self, e, cmd)
            if cmd[0] in cmdlist["lotto"]:
                commands.rand.lotto(self, e, cmd)

                  
                
def main(): 
    username = config.twitch['bot']
    client_id = config.twitch['clientID']
    token = config.twitch['oauth']
    channel = "ekzkvh33"
    bot = TwitchBot(username, client_id, token, channel)  
    bot.start()  
    
if __name__ == "__main__":  
    main()    