from gpiozero import CPUTemperature
import os
import numpy as np
import pandas as pd
import psutil
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import datetime, pytz

# 단위 변환용 함수
def Unit(unit):
    units = ['B', 'K', 'M', 'G', 'T']
    val = units.index(unit)
    if val <= 0:
        return 1
    else:
        return 1024 ** (val)

# 디스크 정보 가져오는 함수
def getDisk(path):
    diskInfo = os.statvfs(path)
    return diskInfo

# 사용한 용량
def getUsed(path):
    diskInfo = getDisk(path)
    used      = diskInfo.f_bsize * (diskInfo.f_blocks - diskInfo.f_bavail)
    return used

# 사용 가능 용량
def getAvailable(path):
    diskInfo = getDisk(path)
    available = diskInfo.f_bsize * diskInfo.f_bavail
    return available

# 전체 크기
def getTotalSize(path):
    diskInfo = getDisk(path)
    total     = diskInfo.f_bsize * diskInfo.f_blocks
    return total

def getRemainDisk():
    return('%.2f' % (getUsed('/') * 100 / getTotalSize('/')) + " % (" + '%.1fGB' % (getUsed('/') / Unit('G')) + " / "+'%.1fGB' % (getTotalSize('/') / Unit('G')) + ")")

def getCPUUsage():
    cpuUsage = psutil.cpu_percent()
    return cpuUsage

def getMemoryUsage():
    memoryUsage = psutil.virtual_memory().percent
    return memoryUsage

# CPU 온도
def getCPUtemperature():
    CPUTemp = CPUTemperature().temperature
    return CPUTemp

def getTempFig():    
    readRPT= pd.read_csv('RPiTemp/RPitemp.csv', names = ['day', 'time', 'data'])
    RPiTemp = readRPT.pivot("day", "time", "data")
    fig = plt.figure()
    fig, ax = plt.subplots(1, 1)
    heatmap = ax.imshow(RPiTemp, cmap = 'YlOrRd')
    tick_space = 1
    ax.set_title('Raspberry Pi Cpu Temperature')
    ax.set_xlabel('Time (h)')
    ax.set_ylabel('Day')
    ax.set_yticks(np.arange(RPiTemp.shape[0]))
    ax.set_yticklabels(np.unique(readRPT.day))
    ax.xaxis.set_major_locator(ticker.MultipleLocator(tick_space))
    c_bar = fig.colorbar(heatmap, orientation = 'vertical')
    sf = plt.savefig('RPiTemp.png', bbox_inches='tight')
    return sf

def getTempMean():
    readRPT= pd.read_csv('RPiTemp/RPitemp.csv', names = ['day', 'time', 'data'])
    getTM = readRPT['data'].mean()
    return getTM

def getTempDayMean():
    readRPT= pd.read_csv('RPiTemp/RPitemp.csv', names = ['day', 'time', 'data'])
    getTDM = readRPT['data'][-24:].mean()
    return getTDM

def getLAtime():
    utc_now = pytz.utc.localize(datetime.datetime.utcnow())
    pst_la = utc_now.astimezone(pytz.timezone("America/Los_Angeles"))
    timeNow = pst_la.strftime("%a %I:%M:%S %p")
    return timeNow

def getKRtime():
    utc_now = pytz.utc.localize(datetime.datetime.utcnow())
    pst_kr = utc_now.astimezone(pytz.timezone("Asia/Seoul"))
    timeNow = pst_kr.strftime("%a %I:%M:%S %p")
    return timeNow
    
