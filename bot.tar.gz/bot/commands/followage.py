import requests
from bs4 import BeautifulSoup
from datetime import datetime

def followAge(userID):
    url = "https://decapi.me/twitch/followed?channel=kuuwang&user="
    user = userID
    site = url + userID
    header = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko'}
    req = requests.get(site, headers = header)
    html = req.text
    parse = BeautifulSoup(html, 'html.parser')
    
    dstr = str(parse)
    if "does not follow kuuwang" in dstr:
        return "0"
    else:
        datetime_object = datetime.strptime(dstr.replace(" (UTC)", ""), '%b %d. %Y - %I:%M:%S %p')
        now = datetime.now()
        followDay = str(now - datetime_object).split(" ")[0]
        return followDay, dstr
    
def do(self, e, cmd): 
    c = self.connection  
    
    get_user_id = e.source.split("!")[0]
    followDay, dstr = followAge(get_user_id)
    d_new = dstr.split(" -")[0]
    
    
    for display_catch in range(10):
        if 'display-name' == e.tags[display_catch]['key']:
            user_display_name = e.tags[display_catch]['value']
            break
    msg = user_display_name + " 님은 Kuuwang 님을 " + followDay + "일째 팔로우 중입니다. (" + d_new + ")"
    c.privmsg(self.channel, msg)