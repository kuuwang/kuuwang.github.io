def survival():
    msg = '쿠왕봇 가동중'
    return msg
    
def kuuwang(): 
    msg = "쿠와아앙"
    return msg
    
def ns():
    msg = '닌텐도 스위치 친구코드 : SW-0274-6024-3440'
    return msg

def twitch():
    msg = "http://twitch.tv/kuuwang"
    return msg
    
def discord():
    msg = "디스코드 : https://discordapp.com/invite/rDMKgVC"
    return msg
    
    
def cl():
    msg = '쿠왕봇 명령어 : !제목, !게임, !업타임, !선택, !시간, !계산, !한영, !영한, !삼보'
    return msg

