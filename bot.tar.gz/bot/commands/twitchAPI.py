import requests
import config
from urllib.request import urlopen

def twitch():
    url = 'https://api.twitch.tv/kraken/users?login=' + config.twitch['channel']  
    headers = {'Client-ID': config.twitch['clientID'], 'Accept': 'application/vnd.twitchtv.v5+json'}  
    r = requests.get(url, headers=headers).json()  
    channel_id = r['users'][0]['_id']  
    url = 'https://api.twitch.tv/kraken/channels/' + channel_id  
    headers = {'Client-ID': config.twitch['clientID'], 'Accept': 'application/vnd.twitchtv.v5+json'}  
    r = requests.get(url, headers=headers).json()
    return r
def twitchviewers():
    url = 'https://api.twitch.tv/kraken/users?login=' + config.twitch['channel']  
    headers = {'Client-ID': config.twitch['clientID'], 'Accept': 'application/vnd.twitchtv.v5+json'}  
    r = requests.get(url, headers=headers).json()  
    channel_id = r['users'][0]['_id']  
    url = 'https://api.twitch.tv/kraken/streams/' +  channel_id  
    headers = {'Client-ID': config.twitch['clientID'], 'Accept': 'application/vnd.twitchtv.v5+json'}  
    r = requests.get(url, headers=headers).json()  
    return r

def twitchviewersJR():
    url = 'https://api.twitch.tv/kraken/users?login=' + config.twitch['ch_jr']  
    headers = {'Client-ID': config.twitch['clientID'], 'Accept': 'application/vnd.twitchtv.v5+json'}  
    r = requests.get(url, headers=headers).json()  
    channel_id = r['users'][0]['_id']  
    url = 'https://api.twitch.tv/kraken/streams/' +  channel_id  
    headers = {'Client-ID': config.twitch['clientID'], 'Accept': 'application/vnd.twitchtv.v5+json'}  
    r = requests.get(url, headers=headers).json()
    print(r)
    return r

def game():
    item = twitch()
    msg = '현재 ' + item['game'] + ' 플레이중'
    return msg

def title():
    item = twitch()
    msg = '방송제목: ' + item['status']
    return msg


def uptime():
    url = 'https://decapi.me/twitch/uptime?channel=kuuwang'
    msg = urlopen(url).read()
    if "offline" in str(msg):
        msg = '방송중이 아닙니다.'
    else:        
        uptime = str(msg).replace("b'", "").replace( ' hours,', '시간').replace(' hour,', '시간').replace(' minutes,', '분',).replace(" seconds'", '초')
        msg =  '현재  ' + uptime + '째 플레이중입니다.'
        
    return msg

def viewersJR():
    try:
        item = twitchviewersJR()
        msg = '옛다 ' + str(item['stream']['viewers']) + ' 명의 관심...'
    except:
        msg = "놀라울만큼, 그 누구도 관심을 주지 않았다. [오프라인 상태]"
    return msg

def viewers():
    try:
        item = twitchviewers()
        msg = '현재' + str(item['stream']['viewers']) + ' 명 시청중'
    except:
        msg = "현재 채널이 오프라인상태입니다."
    return msg