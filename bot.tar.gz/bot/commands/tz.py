import datetime, pytz

def getLAtime():
    utc_now = pytz.utc.localize(datetime.datetime.utcnow())
    pst_la = utc_now.astimezone(pytz.timezone("America/Los_Angeles"))
    timeNow = pst_la.strftime("%a %I:%M:%S %p")
    return timeNow

def getKRtime():
    utc_now = pytz.utc.localize(datetime.datetime.utcnow())
    pst_kr = utc_now.astimezone(pytz.timezone("Asia/Seoul"))
    timeNow = pst_kr.strftime("%a %I:%M:%S %p")
    return timeNow

def do(): 
    msg = '스트리머 시간: ' + str(getLAtime()) + ', 한국 시간: ' + str(getKRtime())
    return msg
        