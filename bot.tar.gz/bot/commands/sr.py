import requests  
import time
import requests
import threading
from bs4 import BeautifulSoup

def get_melon(rank, site):
    header = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko'}
    req = requests.get(site, headers = header)
    html = req.text
    parse = BeautifulSoup(html, 'html.parser')

    titles = parse.find_all("div", {"class": "ellipsis rank01"})
    songs = parse.find_all("div", {"class": "ellipsis rank02"})

    title = []
    song = []

    for t in titles:
        title.append(t.find('a').text)

    for s in songs:
        song.append(s.find('span', {"class": "checkEllipsis"}).text)

    for i in range(rank):
        message = '!sr %s - %s'%(title[i], song[i])
        yield message
        
def nmsearch(search):
    header = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko'}
    url = "https://music.naver.com/search/search.nhn?query="
    query = search
    site = url + query + "&target=track"
    rank = 50
    req = requests.get(site, headers = header)
    html = req.text
    parse = BeautifulSoup(html, 'html.parser')

    titles = parse.find_all("a",{"class":"_title"})

    title = []
    for t in titles:
        title.append(t.find('span').text)

    for i in range(rank):
        message = '!sr %s '%(title[i])
        yield message

def sr(self, e, cmd):  
    c = self.connection          
    
    message = '멜론에서 노래를 받아오는 중...'
    c.privmsg(self.channel, message) 
    RANK = 50
    if "탑백" in cmd:
        site = 'https://www.melon.com/chart/index.htm'
    if "일간" in cmd:
        site = 'https://www.melon.com/chart/day/index.htm'
    if "발라드" in cmd:
        site = 'https://www.melon.com/chart/day/index.htm?classCd=GN0100'
    if "댄스" in cmd:
        site = 'https://www.melon.com/chart/day/index.htm?classCd=GN0200'
    if "랩" in cmd:
        site = 'https://www.melon.com/chart/day/index.htm?classCd=GN0300'
    if "알앤비" in cmd:
        site = 'https://www.melon.com/chart/day/index.htm?classCd=GN0400'
    if "인디" in cmd:
        site = 'https://www.melon.com/chart/day/index.htm?classCd=GN0500'
    if "록" in cmd:
        site = 'https://www.melon.com/chart/day/index.htm?classCd=GN0600'
    if "트로트" in cmd:
        site = 'https://www.melon.com/chart/day/index.htm?classCd=GN0700'
    if "팝" in cmd:
        site = 'https://www.melon.com/chart/day/index.htm?classCd=AB0000'
        
    message = list(get_melon(RANK, site))
    for i in range(RANK):
        c.privmsg(self.channel, message[i])
        time.sleep(10)
    time.sleep(15)
    message = '업로드 완료!'
    c.privmsg(self.channel, message) 