import urllib, json
import urllib.request
import config

def auto_translate(msg):


    urlTrans = "https://openapi.naver.com/v1/papago/n2mt"
    encText = urllib.parse.quote(msg)
    data = "source=en&target=ko&text=" + encText

    request = urllib.request.Request(urlTrans)
    request.add_header("X-Naver-Client-Id", config.jjungrrrr['clientID'])
    request.add_header("X-Naver-Client-Secret", config.jjungrrrr['secret'])

    response = urllib.request.urlopen(request, data=data.encode("utf-8"))

    rescode = response.getcode()
    if (rescode == 200):
        response_body = response.read()
        data = response_body.decode('utf-8')
        data = json.loads(data)
        transText = data['message']['result']['translatedText']
    else:
        print("Error Code:" + rescode)
        transText("에러가 발생했습니다. 다시 입력해주세요.")
    
    return transText

def translate(self, e, cmd):
    c = self.connection

    msg = cmd
    Text = ""

    urlTrans = "https://openapi.naver.com/v1/papago/n2mt"
    vrsize = len(msg)
    vrsize = int(vrsize)
    for i in range(1, vrsize): 
        Text = Text+" "+msg[i]
    encText = urllib.parse.quote(Text)
    if '한영' in msg or "ke" in msg or "번역" in msg:
        data = "source=ko&target=en&text=" + encText
    elif '영한' in msg or "ek" in msg or "tr" in msg:
        data = "source=en&target=ko&text=" + encText
    elif '한일' in msg or "kj" in msg:
        data = "source=ko&target=ja&text=" + encText
    elif '일한' in msg or "jk" in msg:
        data = "source=ja&target=ko&text=" + encText
    elif '한중' in msg or 'kc' in msg:
        data = "source=ko&target=zh-CN&text=" + encText
    elif '중한' in msg or 'ck' in msg:
        data = "source=zh-CN&target=ko&text=" + encText
        

    request = urllib.request.Request(urlTrans)
    request.add_header("X-Naver-Client-Id", config.jjungrrrr['clientID'])
    request.add_header("X-Naver-Client-Secret", config.jjungrrrr['secret'])

    response = urllib.request.urlopen(request, data=data.encode("utf-8"))

    rescode = response.getcode()
    if (rescode == 200):
        response_body = response.read()
        data = response_body.decode('utf-8')
        data = json.loads(data)
        transText = data['message']['result']['translatedText']
    else:
        print("Error Code:" + rescode)

    c.privmsg(self.channel, transText)  