def test():
    x = 1
    y = 1
    print(x)
    print(y)
    return(x + y)