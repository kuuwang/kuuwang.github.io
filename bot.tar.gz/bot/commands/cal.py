import numexpr
def do(cmd):

    msg = cmd
    msg.pop(0)
    m = ''
    n = str(m.join(msg))
    try:
        nmsg = numexpr.evaluate(n).item()
        msg_combine = "쿠왕봇의 논리적인 계산에 의하면..답은 " + str(nmsg) + " !!"
    except OverflowError:
        msg_combine = "숫자가 너무 커욧 !!"
        pass
    except SyntaxError:
        msg_combine = "수학 구문을 잘못 입력하셨습니다 !!" 
        pass
    except:
        msg_combine = "숫자를 입력하세욧 !!"
        pass
    return msg_combine
    
    
def transbin(self, e, cmd):
    c = self.connection 
    msg = cmd
    msg.pop(0)
    if not msg:
        msg_choice = "계산할 게 없는데요..(쭈글)"
    elif msg[0].isdigit() == False:
        msg_choice = "숫자가 아닌데요..(쭈글)"
    else:
        i = int(msg[0])
        msg_choice = bin(i)[2:].zfill(8)
    c.privmsg(self.channel, msg_choice)