import random
import time
def choice(self, e, cmd):
    c = self.connection
    cmd.pop(0)
    print(cmd)
    if not cmd:
        msg = "선택할 게 없습니다."
        pass
    else:
        for display_catch in range(10):
            if 'display-name' == e.tags[display_catch]['key']:
                user_display_name = e.tags[display_catch]['value']
                break
        ##user_display_name = e.tags[4]['value'] 
        print(e)
        sender = user_display_name
        msg_prefix = str(sender) + "님을 위한 선택은 "
        msg = msg_prefix + random.choice(cmd)
    c.privmsg(self.channel, msg)
    
    
    
def choose(cmd):
    str(cmd)
    cmd = cmd.split(" ")
    cmd.pop(0)
    if not cmd:
        msg = "선택할 게 없습니다."
    else:
        msg = random.choice(cmd)
    return msg
    

def lotto(self, e, cmd):
    c = self.connection
    str(cmd)
    cmd.pop(0)

    c.privmsg(self.channel, "쿠왕봇의 추첨번호는...")  
    
    time.sleep(3)
    try: 
        if not cmd:
            lotto = random.sample(range(1, 46), 6)
            lotto.sort()
            msg = ', '.join(map(str, lotto))
            c.privmsg(self.channel, msg)   
        else:
            if int(cmd[0]) <= 5:
                for i in range(0, int(cmd[0])):
                    lotto = random.sample(range(1, 46), 6)
                    lotto.sort()
                    msg = ', '.join(map(str, lotto))
                    c.privmsg(self.channel, msg)
                    time.sleep(2)
            elif int(cmd[0]) > 5:
                nmsg = '도박중독 신고 1366'
                c.privmsg(self.channel, nmsg)        
    except:
        c.privmsg(self.channel,'추첨횟수를 숫자로 작성해주세요. 입력값 : ' + cmd[0]) 
    
    
def dice(self, e, cmd):
    c = self.connection
    dice_one = random.randint(1, 100)
    dice_two = random.randint(1, 100)
    message = "주사위를 굴렸습니다! 결과: " + str(dice_one) + "," + str(dice_two)
    c.privmsg(self.channel, message)  
    
def rag(self, e, cmd):
    c = self.connection
    job = ['아크 비숍(Arch Bishop)','레인져(Ranger)','미케닉(Mechanic)','워록(Warlock)','길로틴 크로스(Guillotine Cross)','룬나이트(Rune Knight)','수라(Shura)','민스트럴(Minstral)','원더러(Wanderer)','제네릭(Genetic)','소서러(Sorcerer)','쉐도우 체이서(Shadow Chaser)','로얄 가드(Royal Guard)','다시선택(Select Again)','리벨리온(Rebelion)','오보로/카게로우(Oboro/Kagerou)','성제(Star Emperor)','소울리퍼(Soul Reaper)','슈퍼노비스(Super Novice)']
    job_choice = random.choice(job)
    job_prefix = "쿠왕봇의 선택은..."
    c.privmsg(self.channel, job_prefix)
    time.sleep(3)
    c.privmsg(self.channel, job_choice)
    
def ragPromo(self, e, cmd):
    c = self.connection
    job = ['아크 비숍(Arch Bishop)','레인져(Ranger)','미케닉(Mechanic)','워록(Warlock)','길로틴 크로스(Guillotine Cross)','룬나이트(Rune Knight)','수라(Shura)','민스트럴(Minstral)','원더러(Wanderer)','제네릭(Genetic)','소서러(Sorcerer)','쉐도우 체이서(Shadow Chaser)','로얄 가드(Royal Guard)','다시선택(Select Again)']
    for display_catch in range(10):
        if 'display-name' == e.tags[display_catch]['key']:
            user_display_name = e.tags[display_catch]['value']
            break    
    ##user_display_name = e.tags[3]['value']
    sender = user_display_name
    job_choice = random.choice(job)

    job_prefix = sender + "님을 위한 쿠왕봇의 선택은..."
    c.privmsg(self.channel, job_prefix)
    time.sleep(3)
    c.privmsg(self.channel, job_choice)    
    
def mhw(self, e, cmd):
    c = self.connection
    weapon = ['대검', '태도', '한손검', '쌍검', '해머', '수렵피리', '랜스', '건랜스', '슬래시액스', '차지액스', '조충곤', '라이트보우건', '헤비보우건', '활']
    weapon_choice = random.choice(weapon)
    weapon_prefix = "쿠왕봇의 선택은..."
    c.privmsg(self.channel, weapon_prefix)
    time.sleep(3)
    c.privmsg(self.channel, weapon_choice)

    
def food(self, e, cmd):
    c = self.connection
    job = ['맥도날드', '롯데리아', '버거킹', 'KFC', '해쉬브라운', '수제버거', '토스트류',  
                   '짜장덮밥', '짜장면', '짬뽕', '짬짜면', '볶음밥', '탕수육', '군만두', '물만두', '찐만두', '떡만둣국','오므라이스',
                   '김치찌개', '된장찌개', '부대찌개', '청국장', '순두부찌개', '순대국밥','설렁탕','선지국밥', '소머리국밥','육개장', '감자탕','아구찜', '해물찜','계란탕(몬)',
                   '물/비빔냉면', '돈까스', '메밀소바', '치즈카츠', '규카츠', '회덮밥','육회비빔밥','카레'
                   '떡볶이', '우동', '라멘', '라면', '튀김', '김밥', '막국수', '쫄면', '함박스테이크','새우튀김',
                   '밥+반찬류(계란후라이, 스팸, 간장, 김, 김치, 멸치볶음, etc...)',
                   '소고기', '삼겹살', '스테이크',  '슈바인학센',
                   '생선', '곱창', '막창', '초밥(연어)',
                   '피자','민트초코파인애플피자',
                   '후라이드치킨', '양념치킨', '구운치킨', '닭발','닭똥집',
                   
                   '제육덮밥', '비빔밥', '오므라이스', '카레', '짜장밥', '회덮밥', '쌈밥', '김치볶음밥',
                   '김치찌개', '부대찌개', '된장찌개', '육개장', '순두부찌개','돼지국밥', '매운탕', '해물탕', '뼈해장국',
                   '핫도그', '김밥', '순대', '어묵', '라볶이', '만두',
                   '칼국수', '비빔국수', '잔치국수', '스파게티', '막국수', '쫄면',
                   '우동', '카츠동', '하이라이스', '오코노미야끼', '초밥', '규동', '라멘', '소바', '돈부리', 
                   '삼각김밥', '햄버거', '토스트', '컵라면', '도시락', '밥버거', '빵', '샌드위치', '죽',
                   '족발(보쌈)', '곱(막)창', '콘치즈', '골뱅이무침', '오뎅탕',
                   '마파두부', '깐풍기', '고추잡채', '팔보채', '깐쇼새우',
                   
                  
                  
                  '다시선택', '굶기'
                  
                  ]
    job_choice = random.choice(job)
    job_prefix = "쿠왕봇의 선택은... " + job_choice
    c.privmsg(self.channel, job_prefix)

        