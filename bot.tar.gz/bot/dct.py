## 디스코드 쿠왕봇 

import asyncio
import discord
import config
import cmdlist
import random
import kuuwAPI
import commands
import numexpr
import openpyxl
import infoRPi
import requests
import time
from json import loads

## 커맨드 리스트 획득, 사실상 필요없다.
cmdlist = cmdlist.cmds

## 디스코드 클라이언트 실행
client = discord.Client()
botStart = time.time()
win = 0
lose = 0
draw = 0


@client.event
async def on_ready():
    print('We have logged in as {0.user}'.format(client))
    print(discord.__version__)
    
    ## 봇 플레이중인 게임 변경
    game = discord.Game("쿠와아아아앙")
    await client.change_presence(status = discord.Status.online, activity = game)     

    
@client.event
async def on_message(message):
    global win, lose, draw
    cmd_prefix = "!"
    cmd = message.content[1:] 
    print(message.author.id)
    if message.content.startswith('{0}'.format(cmd_prefix)):    
        if message.author == client.user:
            return

        if message.content.startswith("{0}쿠왕".format(cmd_prefix)):
            await message.channel.send(commands.msgs.kuuwang())

        if message.content.startswith("{0}가위".format(cmd_prefix)) or message.content.startswith("{0}바위".format(cmd_prefix)) or message.content.startswith("{0}보".format(cmd_prefix)):
            file = openpyxl.load_workbook("db/rcp.xlsx")
            sheet = file.active
            i = 1
            rcp_box = ["가위", "바위", "보"]
            rcp = random.choice(rcp_box)            
            while True:
                if cmd == rcp: 
                    if sheet["A" + str(i)].value == str(message.author.id): #유저아이디 확인
                            sheet["D" + str(i)].value = sheet["D" + str(i)].value + 1  #승         
                            await message.channel.send("쿠왕봇은 " + rcp + "를 냈습니다. {0.author.mention}님과 무승부\n".format(message) + "(승 : " +str(sheet["B" + str(i)].value) + ", 패 : " + str(sheet["C" + str(i)].value) + ", 무 : " + str(sheet["D" + str(i)].value) + ")")
                if cmd == "가위" and rcp == "보" or cmd == "바위" and rcp == "가위" and cmd == "보" and rcp == "바위":
                    if sheet["A" + str(i)].value == str(message.author.id): #유저아이디 확인
                            sheet["B" + str(i)].value = sheet["B" + str(i)].value + 1  #승         
                            await message.channel.send("쿠왕봇은 " + rcp + "를 냈습니다. {0.author.mention}님의 승리\n".format(message) + "(승 : " +str(sheet["B" + str(i)].value) + ", 패 : " + str(sheet["C" + str(i)].value) + ", 무 : " + str(sheet["D" + str(i)].value) + ")")                
                else:
                    if sheet["A" + str(i)].value == str(message.author.id): #유저아이디 확인
                            sheet["C" + str(i)].value = sheet["C" + str(i)].value + 1  #승         
                            await message.channel.send("쿠왕봇은 " + rcp + "를 냈습니다. {0.author.mention}님의 패배\n".format(message) + "(승 : " +str(sheet["B" + str(i)].value) + ", 패 : " + str(sheet["C" + str(i)].value) + ", 무 : " + str(sheet["D" + str(i)].value) + ")")                
                
                file.save("db/rcp.xlsx")
                break                        
                if sheet["A" + str(i)].value == None:
                    sheet["A" + str(i)].value = str(message.author.id)
                    sheet["B" + str(i)].value = 0 #승
                    sheet["C" + str(i)].value = 0 #패
                    sheet["D" + str(i)].value = 0 #무
                file.save("db/rcp.xlsx")
                break                    
            

#            if rcp_choice == "바위":

#                win = win + 1
#                await message.channel.send("쿠왕봇은 바위를 냈습니다. 패배")
#                await message.channel.send("win : {0}, lose : {1}, draw : {2}".format(win, lose, draw))
#            elif rcp_choice == "보":
#                lose = lose + 1
#                await message.channel.send("쿠왕봇은 보를 냈습니다. 승리")
#                await message.channel.send("win : {0}, lose : {1}, draw : {2}".format(win, lose, draw))
#            elif rcp_choice == "가위":
#                draw = draw + 1
#                await message.channel.send("쿠왕봇은 가위를 냈습니다. 무승부")
#                await message.channel.send("win : {0}, lose : {1}, draw : {2}".format(win, lose, draw))
                
                
        if cmd in cmdlist["time"]:
            embed = discord.Embed(title="시간(사실 시각이 정확한 단어입니다.)", color=0x6d89c1)
            embed.add_field(name="스트리머 시간", value=commands.tz.getLAtime(), inline=False)
            embed.add_field(name="한국 시간", value=commands.tz.getKRtime(), inline=False)
            await message.channel.send(embed=embed)  



        if message.content.startswith("{0}선택".format(cmd_prefix)) or message.content.startswith("{0}ㅅㅌ".format(cmd_prefix)) :
            msg = message.content.split(" ")
            msg.pop(0)
            print(msg)
            msg_choice = random.choice(msg)
            msg_choice = commands.rand.choose(message.content)
            embed = discord.Embed(color=0x6d89c1)
            embed.add_field(name="쿠왕봇의 논리적인 추론에 의하면...", value=msg_choice, inline=True)
            await message.channel.send(embed = embed)# 스트리머동네 시간    



            
client.run('NzQ1NjQwMTE2NDQ5NTc0OTMy.Xz0teQ.7f2uHo0eDaHnEmfglle-3OgNnI4')
