twitch = {
    'channel'   :   'kuuwang',
    'ch_ghost'	:	'ghostdaa',
    'ch_fp'		:	'flyinpig10',
    'ch_ka'     :   'kasin_tv',
    'ch_wr'     :   'woora_tv',
    'ch_jr'     :   'jjungrrrr',
    'bot'		:	'kuuwang_bot',
    'clientID'	:	'0ilk1btjhnvpwpgud52jwg057ma07a',
    'oauth'		:	'1s5a5u3zy602f0iw9lb20x9clezys6'
}

kuusic = {
    'clientID' : 'y5ssaxlrvid6rvz3a89jvthp8wyuzp',
    'oauth' : 'ysw5zpyegh7n9kpn9xfy0xf2cuxxs7'
}


discord = {
    'TOKEN'    : 'NTE4MzkyNDY4MDQ0MTIwMDc0.XnHamg.D46cVIlXhLQRHEUxScQ2V-KMLXQ',
    'notify'   : '745371100032139354'
}

jjungrrrr={
    'clientID' : 'b5zmFUKJhd_DEqUazduH',
    'secret'   : 'jif0bWswtL,',
}

naverTR = {
    'clientID' : 'QPpwsuavQi6H6aDEO78s',
    'secret'   : '2AdbS51n6v',   
}
kasin={
    'clientID' : '_jOAzl_fW9orxMyrfGrx',
    'secret'   : 'QSxFFCXXHr',       
}
woora={
    'clientID' : '0rWUN4iOu7P1fU4sgBFh',
    'secret'   : 'jmlNjvdbXC',       
    
}

