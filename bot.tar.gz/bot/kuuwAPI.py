import random
import urllib, json
import urllib.request
import config

hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
       'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
       'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
       'Accept-Encoding': 'none',
       'Accept-Language': 'en-US,en;q=0.8',
       'Connection': 'keep-alive'}

def cetusInfo():
    urlCetus = "https://api.warframestat.us/pc/cetusCycle"
    req = urllib.request.Request(urlCetus, headers = hdr)
    data = json.loads(urllib.request.urlopen(req).read())
    timeLeft =data['timeLeft']
    isDay = data['isDay']
    if isDay == True:
        return("테랄과의 만남이 "+timeLeft+" 남았습니다.")
    elif isDay == False:
        return("테랄 출현중! 남은 시간 "+timeLeft)

def dogImage():
    dog_prefix = "https://dog.ceo/api/breed/"
    dog_suffix = "/images/random"
    dog = ['samoyed', 'malamute', 'husky', 'pembroke', 'dachshund']
    urlDog = dog_prefix + random.choice(dog) + dog_suffix
    req = urllib.request.Request(urlDog, headers=hdr)
    data = json.loads(urllib.request.urlopen(req).read())
    image = data['message']
    return image

def catImage():
    urlCat = "https://aws.random.cat/meow"
    req = urllib.request.Request(urlCat, headers=hdr)
    data = json.loads(urllib.request.urlopen(req).read())
    image = data['file']
    return image


def translate(message):
    msg = message.split(" ")
    Text = ""

    urlTrans = "https://openapi.naver.com/v1/papago/n2mt"
    vrsize = len(msg)
    vrsize = int(vrsize)
    for i in range(1, vrsize): 
        Text = Text+" "+msg[i]
    encText = urllib.parse.quote(Text)
    if '한영' in msg or "ke" in msg:
        data = "source=ko&target=en&text=" + encText
    elif '영한' in msg or "ek" in msg or "tr" in msg:
        data = "source=en&target=ko&text=" + encText
    elif '한일' in msg:
        data = "source=ko&target=ja&text=" + encText
    elif '일한' in msg:
        data = "source=ja&target=ko&text=" + encText

    request = urllib.request.Request(urlTrans)
    request.add_header("X-Naver-Client-Id", config.client_id)
    request.add_header("X-Naver-Client-Secret", config.client_secret)

    response = urllib.request.urlopen(request, data=data.encode("utf-8"))

    rescode = response.getcode()
    if (rescode == 200):
        response_body = response.read()
        data = response_body.decode('utf-8')
        data = json.loads(data)
        transText = data['message']['result']['translatedText']
    else:
        print("Error Code:" + rescode)

    return transText