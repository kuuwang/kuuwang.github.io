import sys, re
import irc.bot  
import requests  
import config
import time
import requests
import asyncio
import threading
from bs4 import BeautifulSoup

def get_melon(rank, site):
    header = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko'}
    req = requests.get(site, headers = header)
    html = req.text
    parse = BeautifulSoup(html, 'html.parser')

    titles = parse.find_all("div", {"class": "ellipsis rank01"})
    songs = parse.find_all("div", {"class": "ellipsis rank02"})

    title = []
    song = []

    for t in titles:
        title.append(t.find('a').text)

    for s in songs:
        song.append(s.find('span', {"class": "checkEllipsis"}).text)

    for i in range(rank):
        message = '!sr %s - %s'%(title[i], song[i])
        yield message

def nmsearch(search):
    header = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko'}
    url = "https://music.naver.com/search/search.nhn?query="
    query = search
    site = url + query + "&target=track"
    rank = 50
    req = requests.get(site, headers = header)
    html = req.text
    parse = BeautifulSoup(html, 'html.parser')

    titles = parse.find_all("a",{"class":"_title"})

    title = []
    for t in titles:
        title.append(t.find('span').text)

    for i in range(rank):
        message = '!sr %s '%(title[i])
        yield message
        
class TwitchBot(irc.bot.SingleServerIRCBot):  
    def __init__(self, username, client_id, token, channel):  
        self.client_id = client_id  
        self.token = token  
        self.channel = '#' + channel  
        self.hogumastack = 0  
  
        #채널 ID를 얻기 위해 v5 API 호출  
        url = 'https://api.twitch.tv/kraken/users?login=' + channel  
        headers = {'Client-ID': client_id, 'Accept': 'application/vnd.twitchtv.v5+json'}  
        r = requests.get(url, headers=headers).json()  
        self.channel_id = r['users'][0]['_id']  
  
        # IRC bot 연결 생성  
        server = 'irc.chat.twitch.tv'  
        port = 6667  
        print('서버 ' + server + ', 포트 ' + str(port) + '에 연결 중...')  
        irc.bot.SingleServerIRCBot.__init__(self, [(server, port, 'oauth:' + token)], username, username)  
  
    def on_welcome(self, c, e):  
        print(self.channel + '에 연결되었습니다.')  
  
        #봇을 사용하기 전에 채널 권한 부여가 필요  
        c.cap('REQ', ':twitch.tv/membership')  
        c.cap('REQ', ':twitch.tv/tags')  
        c.cap('REQ', ':twitch.tv/commands')  
        c.join(self.channel)  
  
    def on_pubmsg(self, c, e):  
        # If a chat message starts with an exclamation point, try to run it as a command
        if e.arguments[0][:1] == '!':
            cmd = e.arguments[0][1:]
            #print('Received command: ' + cmd)
            print(cmd)
            self.do_command(e, cmd)
        return
    
    def do_command(self, e, cmd):  
        c = self.connection  
        
        if cmd == "큐직명령어":
            message = "큐직봇: !탑백 !일간 !발라드 !댄스 !힙합 !트로트 !알앤비 !인디 !록 !포크 !팝백"
            c.privmsg(self.channel, message)
        elif cmd == "t":
            for i in range(100):
                time.sleep(1)
                TwitchBot.on_pubmsg(self, c, e)
                print(i)
        elif "앨범" in cmd:
            msg = cmd.split(" ")
            msg.pop(0)
            msg = str(msg[0])
            RANK = 10
            if not msg: 
                msg_choice = "검색할 앨범이 없는데요..(쭈글)"
            else:
                message = '네이버 뮤직에서 ' + msg + '님의 곡 검색중...'
                c.privmsg(self.channel, message)
                message = list(nmsearch(msg))
                for i in range(RANK):
                    c.privmsg(self.channel, message[i] + msg)
                    time.sleep(10)
                time.sleep(15)
                message = '업로드 완료!'
                c.privmsg(self.channel, message) 
        elif cmd == "탑백":
            message = '멜론에서 노래를 받아오는 중...'
            c.privmsg(self.channel, message) 
            RANK = 50
            site = 'https://www.melon.com/chart/index.htm'
            message = list(get_melon(RANK, site))
            for i in range(RANK):
                c.privmsg(self.channel, message[i])
                time.sleep(10)
            time.sleep(15)
            message = '업로드 완료!'
            c.privmsg(self.channel, message) 
            
        elif cmd == "일간":
            message = '멜론에서 노래를 받아오는 중...'
            c.privmsg(self.channel, message) 
            RANK = 50
            site = 'https://www.melon.com/chart/day/index.htm'
            message = list(get_melon(RANK, site))
            for i in range(RANK):
                c.privmsg(self.channel, message[i])
                time.sleep(10)
            time.sleep(15)
            message = '업로드 완료!'
            c.privmsg(self.channel, message) 

        elif cmd == "발라드":
            message = '멜론에서 [일간 발라드] 를 받아오는 중...'
            c.privmsg(self.channel, message) 
            RANK = 50
            site = 'https://www.melon.com/chart/day/index.htm?classCd=GN0100'
            message = list(get_melon(RANK, site))
            for i in range(RANK):
                c.privmsg(self.channel, message[i])
                time.sleep(10)
            time.sleep(15)
            message = '업로드 완료!'
            c.privmsg(self.channel, message)             

        elif cmd == "댄스":
            message = '멜론에서 [일간 댄스] 를 받아오는 중...'
            c.privmsg(self.channel, message) 
            RANK = 50
            site = 'https://www.melon.com/chart/day/index.htm?classCd=GN0200'
            message = list(get_melon(RANK, site))
            for i in range(RANK):
                c.privmsg(self.channel, message[i])
                time.sleep(10)
            time.sleep(15)
            message = '업로드 완료!'
            c.privmsg(self.channel, message)  

        elif cmd == "랩" or cmd == "힙합":
            message = '멜론에서 [일간 랩/힙합] 를 받아오는 중...'
            c.privmsg(self.channel, message) 
            RANK = 50
            site = 'https://www.melon.com/chart/day/index.htm?classCd=GN0300'
            message = list(get_melon(RANK, site))
            for i in range(RANK):
                c.privmsg(self.channel, message[i])
                time.sleep(10)
            time.sleep(15)
            message = '업로드 완료!'
            c.privmsg(self.channel, message)              
            
        elif cmd == "알앤비":
            message = '멜론에서 [일간 R&B] 를 받아오는 중...'
            c.privmsg(self.channel, message) 
            RANK = 50
            site = 'https://www.melon.com/chart/day/index.htm?classCd=GN0400'
            message = list(get_melon(RANK, site))
            for i in range(RANK):
                c.privmsg(self.channel, message[i])
                time.sleep(10)
            time.sleep(15)
            message = '업로드 완료!'
            c.privmsg(self.channel, message)

        elif cmd == "인디":
            message = '멜론에서 [일간 인디음악] 을 받아오는 중...'
            c.privmsg(self.channel, message) 
            RANK = 50
            site = 'https://www.melon.com/chart/day/index.htm?classCd=GN0500'
            message = list(get_melon(RANK, site))
            for i in range(RANK):
                c.privmsg(self.channel, message[i])
                time.sleep(10)
            time.sleep(15)
            message = '업로드 완료!'
            c.privmsg(self.channel, message)    

        elif cmd == "록" or cmd == "메탈":
            message = '멜론에서 [일간 록/메탈] 을 받아오는 중...'
            c.privmsg(self.channel, message) 
            RANK = 50
            site = 'https://www.melon.com/chart/day/index.htm?classCd=GN0600'
            message = list(get_melon(RANK, site))
            for i in range(RANK):
                c.privmsg(self.channel, message[i])
                time.sleep(10)
            time.sleep(15)
            message = '업로드 완료!'
            c.privmsg(self.channel, message)                

        elif cmd == "트로트":
            message = '멜론에서 [일간 트로트] 을 받아오는 중...'
            c.privmsg(self.channel, message) 
            RANK = 50
            site = 'https://www.melon.com/chart/day/index.htm?classCd=GN0700'
            message = list(get_melon(RANK, site))
            for i in range(RANK):
                c.privmsg(self.channel, message[i])
                time.sleep(10)
            time.sleep(15)
            message = '업로드 완료!'
            c.privmsg(self.channel, message)     

        elif cmd == "포크" or cmd == "블루스":
            message = '멜론에서 [일간 포크/블루스] 을 받아오는 중...'
            c.privmsg(self.channel, message) 
            RANK = 50
            site = 'https://www.melon.com/chart/day/index.htm?classCd=GN0700'
            message = list(get_melon(RANK, site))
            for i in range(RANK):
                c.privmsg(self.channel, message[i])
                time.sleep(10)
            time.sleep(15)
            message = '업로드 완료!'
            c.privmsg(self.channel, message)     
                        
            
        elif cmd == "드라마":
            message = '멜론에서 [드라마 ost]를 받아오는 중...'
            c.privmsg(self.channel, message) 
            RANK = 50
            site = 'https://www.melon.com/chart/month/index.htm?classCd=GN1500'
            message = list(get_melon(RANK, site))
            for i in range(RANK):
                c.privmsg(self.channel, message[i])
                time.sleep(10)
            time.sleep(15)
            message = '업로드 완료!'
            c.privmsg(self.channel, message) 
            
        elif cmd == "생존":
            message = "큐직봇 생존신고 완료!"
            c.privmsg(self.channel, message)
            
    
    
def main():  
    username = "큐직" # 별 의미 없습니다. 봇 계정의 이름은 twitch 사이트에서 조정해주면 됩니다.  
    client_id = config.kuusic['clientID']# Client ID  
    token = config.kuusic['oauth'] # oauth: 는 빼고 뒷부분만 적어주시면 됩니다.  
    channel = config.twitch['channel'] # 봇이 접속할 채널입니다. 테스트할 땐 본인의 트위치 계정을 적어주세요.
  
    bot = TwitchBot(username, client_id, token, channel)  
#    try:
    bot.start()
#    except:
#        pass
    
if __name__ == "__main__":  
    main()