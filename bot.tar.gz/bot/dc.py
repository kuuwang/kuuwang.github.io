import asyncio
import discord
import config
import cmdlist
import random
import kuuwAPI
import commands
import numexpr
import infoRPi
import requests
import openpyxl
import time
from bs4 import BeautifulSoup
from json import loads
cmdlist = cmdlist.cmds

client = discord.Client()
botStart = time.time()

@client.event
async def on_ready():
    print('We have logged in as {0.user}'.format(client))
    print(discord.__version__)
    game = discord.Game("쿠와아아아앙")
    await client.change_presence(status = discord.Status.online, activity = game)
    
    
#################################################################################
################################ 방송 자동알림 코드 ##############################
#################################################################################
#    channel = "kuuwang"
#    name = "Kuuwang"
#    channel = client.get_channel(745371100032139354)
#    twitch_live = 0
#  
#    while True:
#        url = 'https://api.twitch.tv/kraken/users?login=kuuwang'  
#        headers = {'client-id': config.twitch['clientID'], 'Accept': 'application/vnd.twitchtv.v5+json'}  
#        response = requests.get(url, headers=headers).json()
#        channel_id = response['users'][0]['_id']  
#        url = 'https://api.twitch.tv/kraken/streams/' +  channel_id  
#        headers = {'Client-ID': config.twitch['clientID'], 'Accept': 'application/vnd.twitchtv.v5+json'}  
#        r = requests.get(url, headers=headers).json()
#        try:
#            if r['stream'] == None and twitch_live == 1:
                
#                embed = discord.Embed(title="Kuuwang 님의 방송이 종료되었습니다.", url = 'https://twitch.tv/kuuwang', color=0x6d89c1)
#                embed.add_field(name=":flag_us:", value=commands.tz.getLAtime(), inline=True)
#                embed.add_field(name=":flag_kr:", value=commands.tz.getKRtime(), inline=True)
#                await channel.send(embed=embed)
#                twitch_live = 0
#            if r['stream']['stream_type'] == 'live' and twitch_live == 0:
#                
#                embed = discord.Embed(title="Kuuwang 님이 생방송중입니다.", url = 'https://twitch.tv/kuuwang', color=0x6d89c1)
#                embed.add_field(name=":tv:", value=r['stream']['channel']['status'], inline = True)
#                embed.add_field(name=":video_game:", value=r['stream']['game'], inline = False)
#                
#                embed.add_field(name=":flag_us:", value=commands.tz.getLAtime(), inline=True)
#                embed.add_field(name=":flag_kr:", value=commands.tz.getKRtime(), inline=True)
#                
#                embed.set_image(url=r['stream']['channel']['video_banner'])
                
#                await channel.send("@everyone")
#                await channel.send(embed=embed)
#                twitch_live = 1

#        except:
#            twitch_live = 0
#        await asyncio.sleep(5)


#################################################################################
################################ 방송 자동알림 코드 ##############################
#################################################################################        



@client.event
async def on_message(message):

    if message.content.startswith('#'):
        msg = message.content[1:]
        
        
        url = 'https://search.naver.com/search.naver?where=image&sm=tab_jum&query=' + msg
        
        res = requests.get(url).content.decode()
        soup = BeautifulSoup(res, 'html.parser')
        imgs = soup.findAll('img', class_='_img')
        for img in imgs[:1]: 
            embed = discord.Embed(color = 0x2db400)
            embed.set_image(url = img.get('data-source'))
            await message.channel.send(embed = embed)            
            
    cmd_prefix = "!"#명령어 설정 
    cmd = message.content[1:] 

    if message.content.startswith('{0}'.format(cmd_prefix)) and message.author.id != 745640116449574932:    
        if message.author == client.user:
            return

        if message.content.startswith("!선택") or message.content.startswith("!ㅅㅌ") :
            msg = message.content.split(" ")
            msg.pop(0)
            msg_choice = random.choice(msg)
            msg_choice = commands.rand.choose(message.content)
            embed = discord.Embed(color=0x6d89c1)
            embed.add_field(name="쿠왕봇의 논리적인 추론에 의하면...", value=msg_choice, inline=True)
            await message.channel.send(embed = embed)# 스트리머동네 시간    

        if cmd in cmdlist["rag"]:
            embed = discord.Embed(color = 0x6d89c1)
            job = ['아크 비숍(Arch Bishop)','레인져(Ranger)','미케닉(Mechanic)','워록(Warlock)','길로틴 크로스(Guillotine Cross)','룬나이트(Rune Knight)','수라(Shura)','민스트럴(Minstral)','원더러(Wanderer)','제네릭(Genetic)','소서러(Sorcerer)','쉐도우 체이서(Shadow Chaser)','로얄 가드(Royal Guard)','다시선택(Select Again)','리벨리온(Rebelion)','오보로/카게로우(Oboro/Kagerou)','성제(Star Emperor)','소울리퍼(Soul Reaper)','슈퍼노비스(Super Novice)']
            job_choice = random.choice(job)
            job_prefix = "쿠왕봇의 선택은..."
            embed.add_field(name="쿠왕봇의 선택은...", value=job_choice, inline=False)
            await message.channel.send(embed=embed)     
            
            
            
            
            
        if cmd in cmdlist["time"]:
            embed = discord.Embed(title="시간(사실 시각이 정확한 단어입니다.)", color=0x6d89c1)
            embed.add_field(name="스트리머 시간", value=commands.tz.getLAtime(), inline=False)
            embed.add_field(name="한국 시간", value=commands.tz.getKRtime(), inline=False)
            await message.channel.send(embed=embed)   
        if message.content.startswith("!테스트"):
            embed = discord.Embed(title="Title", description="Desc", color=0x6d89c1)
            embed.add_field(name="Field1", value="hi", inline=False)
            embed.add_field(name="Field2", value="hi2", inline=False)
            await message.channel.send(embed=embed)
        if cmd in cmdlist["uptime"]:
            embed = discord.Embed(title="업타임", description=commands.twitchAPI.uptime(), color=0x6d89c1)
            await message.channel.send(embed=embed)            

        if cmd in cmdlist["title"]:
            embed = discord.Embed(title="방송제목", description=commands.twitchAPI.title(), color=0x6d89c1)
            await message.channel.send(embed=embed)
        if cmd in cmdlist["game"]:
            embed = discord.Embed(title="방송제목", description=commands.twitchAPI.game(), color=0x6d89c1)
            await message.channel.send(embed=embed)
        elif cmd in cmdlist["dog"]:
            embed = discord.Embed(color = 0x6d89c1)
            embed.set_image(url = kuuwAPI.dogImage())
            await message.channel.send(embed = embed)

        elif cmd in cmdlist["cat"]:
            embed = discord.Embed(color = 0x6d89c1)
            embed.set_image(url = kuuwAPI.catImage())
            await message.channel.send(client.get_channel('698580457897459712'), embed = embed)        
        if message.content.startswith('!쿠왕'):
            await message.channel.send('{0.author.mention}은(는) 크고 아름답게 소리쳤다. 쿠왕!'.format(message))
        if message.content.startswith('!뱃살'):
            sal = random.randint(60, 101)            
            await message.channel.send('{0.author.mention}님의 몸무게는...'.format(message) + str(sal) + "kg !!")

################################ 이모티콘 ##############################             

        if message.content.startswith('!멍'):
            await message.channel.send(file = discord.File('emojis/Abs.gif'))
            
        if message.content.startswith('!화'):
            await message.channel.send(file = discord.File('emojis/Agh.gif'))
            
        if message.content.startswith('!짜증'):
            await message.channel.send(file = discord.File('emojis/Ang.gif'))   
            
        if message.content.startswith('!멋져'):
            await message.channel.send(file = discord.File('emojis/Awsm.gif'))            
            
        if message.content.startswith('!찌릿'):
            await message.channel.send(file = discord.File('emojis/Bzz.gif'))
        
        if message.content.startswith('!컴온'):
            await message.channel.send(file = discord.File('emojis/Come.gif'))

        if message.content.startswith('!시끌'):
            await message.channel.send(file = discord.File('emojis/Crwd.gif'))
            
        if message.content.startswith('!otl'):
            await message.channel.send(file = discord.File('emojis/Desp.gif'))
            
        if message.content.startswith('!덤덤'):
            await message.channel.send(file = discord.File('emojis/Dum.gif'))   
            
        if message.content.startswith('!러브'):
            await message.channel.send(file = discord.File('emojis/E20.gif'))            
            
        if message.content.startswith('!엑스'):
            await message.channel.send(file = discord.File('emojis/Ecks.gif'))
        
        if message.content.startswith('!탈력'):
            await message.channel.send(file = discord.File('emojis/Ene.gif'))
                        
        if message.content.startswith('!느낌표'):
            await message.channel.send(file = discord.File('emojis/Exc.gif'))
            
        if message.content.startswith('!번쩍'):
            await message.channel.send(file = discord.File('emojis/Fsh.gif'))
            
        if message.content.startswith('!킥킥'):
            await message.channel.send(file = discord.File('emojis/Ggg.gif'))
            
        if message.content.startswith('!...'):
            await message.channel.send(file = discord.File('emojis/gif.gif'))   
            
        if message.content.startswith('!go'):
            await message.channel.send(file = discord.File('emojis/Goo.gif'))            
            
        if message.content.startswith('!축하'):
            await message.channel.send(file = discord.File('emojis/Grat.gif'))
        
        if message.content.startswith('!하하'):
            await message.channel.send(file = discord.File('emojis/Heh.gif'))

        if message.content.startswith('!긁적'):
            await message.channel.send(file = discord.File('emojis/Hmm.gif'))
            
        if message.content.startswith('!흠'):
            await message.channel.send(file = discord.File('emojis/Hum.gif'))
            
        if message.content.startswith('!쪽'):
            await message.channel.send(file = discord.File('emojis/Kis.gif'))   
            
        if message.content.startswith('!쪽쪽'):
            await message.channel.send(file = discord.File('emojis/Kis2.gif'))            
            
        if message.content.startswith('!메롱'):
            await message.channel.send(file = discord.File('emojis/Meh.gif'))
        
        if message.content.startswith('!돈'):
            await message.channel.send(file = discord.File('emojis/Money.gif'))
                        
        if message.content.startswith('!최고'):
            await message.channel.send(file = discord.File('emojis/No1.gif'))            
            
        if message.content.startswith('!헉'):
            await message.channel.send(file = discord.File('emojis/Omg.gif'))
        
        if message.content.startswith('!아니'):
            await message.channel.send(file = discord.File('emojis/Ono.gif'))
                        
        if message.content.startswith('!부끄'):
            await message.channel.send(file = discord.File('emojis/Shy.gif'))                  
            
        if message.content.startswith('!하아'):
            await message.channel.send(file = discord.File('emojis/Sigh.gif'))                  
                
        if message.content.startswith('!질질'):
            await message.channel.send(file = discord.File('emojis/Sur.gif'))  
            
        if message.content.startswith('!미안'):
            await message.channel.send(file = discord.File('emojis/Sry.gif'))            
            
        if message.content.startswith('!땀'):
            await message.channel.send(file = discord.File('emojis/Swt.gif'))
 
        if message.content.startswith('!하품'):
            await message.channel.send(file = discord.File('emojis/Yawm.gif'))
            
        if message.content.startswith('!?') or message.content.startswith('!물음표'):
            await message.channel.send(file = discord.File('emojis/Que.gif'))
                        

        if message.content.startswith('!선넘'):
            await message.channel.send(file = discord.File('emojis/tjssja.JPG'))

        if message.content.startswith('!헐'):
            await message.channel.send(file = discord.File('emojis/unknown.png'))            
            
################################ 방송알림(수동) ##############################                
        if message.content.startswith('!방송'):    
            if message.author.name != 'Kuuwang':

                await message.channel.send('메롱')
            else:
                url = 'https://api.twitch.tv/kraken/users?login=kuuwang'  
                headers = {'client-id': config.twitch['clientID'], 'Accept': 'application/vnd.twitchtv.v5+json'}  
                response = requests.get(url, headers=headers).json()
                channel_id = response['users'][0]['_id']  
                url = 'https://api.twitch.tv/kraken/streams/' +  channel_id  
                headers = {'Client-ID': config.twitch['clientID'], 'Accept': 'application/vnd.twitchtv.v5+json'}  
                r = requests.get(url, headers=headers).json()                
                
                
                channel = client.get_channel(745371100032139354)
                embed = discord.Embed(title="Kuuwang 님이 생방송중입니다.", url = 'https://twitch.tv/kuuwang', color=0x6d89c1)
                embed.add_field(name=":tv:", value=r['stream']['channel']['status'], inline = True)
                embed.add_field(name=":video_game:", value=r['stream']['game'], inline = False)
                
                embed.add_field(name=":flag_us:", value=commands.tz.getLAtime(), inline=True)
                embed.add_field(name=":flag_kr:", value=commands.tz.getKRtime(), inline=True)
                
                embed.set_image(url=r['stream']['channel']['video_banner'])
               
                await channel.send("@everyone")
                await channel.send(embed=embed)                
            


            
################################ 뭐먹지 ##############################          
        if message.content.startswith('!뭐먹지') or message.content.startswith('!머묵노'):
            embed = discord.Embed(color = 0x6d89c1)
            job = ['맥도날드', '롯데리아', '버거킹', 'KFC', '해쉬브라운', '수제버거', '토스트류',  
                   '짜장덮밥', '짜장면', '짬뽕', '짬짜면', '볶음밥', '탕수육', '군만두', '물만두', '찐만두', '떡만둣국','오므라이스',
                   '김치찌개', '된장찌개', '부대찌개', '청국장', '순두부찌개', '순대국밥','설렁탕','선지국밥', '소머리국밥','육개장', '감자탕','아구찜', '해물찜','계란탕(몬)',
                   '물/비빔냉면', '돈까스', '메밀소바', '치즈카츠', '규카츠', '회덮밥','육회비빔밥','카레'
                   '떡볶이', '우동', '라멘', '라면', '튀김', '김밥', '막국수', '쫄면', '함박스테이크','새우튀김',
                   '밥+반찬류(계란후라이, 스팸, 간장, 김, 김치, 멸치볶음, etc...)',
                   '소고기', '삼겹살', '스테이크',  '슈바인학센',
                   '생선', '곱창', '막창', '초밥(연어)',
                   '피자','민트초코파인애플피자',
                   '후라이드치킨', '양념치킨', '구운치킨', '닭발','닭똥집',
                   
                   '제육덮밥', '비빔밥', '오므라이스', '카레', '짜장밥', '회덮밥', '쌈밥', '김치볶음밥',
                   '김치찌개', '부대찌개', '된장찌개', '육개장', '순두부찌개','돼지국밥', '매운탕', '해물탕', '뼈해장국',
                   '핫도그', '김밥', '순대', '어묵', '라볶이', '만두',
                   '칼국수', '비빔국수', '잔치국수', '스파게티', '막국수', '쫄면',
                   '우동', '카츠동', '하이라이스', '오코노미야끼', '초밥', '규동', '라멘', '소바', '돈부리', 
                   '삼각김밥', '햄버거', '토스트', '컵라면', '도시락', '밥버거', '빵', '샌드위치', '죽',
                   '족발(보쌈)', '곱(막)창', '콘치즈', '골뱅이무침', '오뎅탕',
                   '마파두부', '깐풍기', '고추잡채', '팔보채', '깐쇼새우',
                   
                  
                  
                  '다시선택', '굶기'
                  
                  ]
            job_choice = random.choice(job)
            job_prefix = "쿠왕봇의 선택은..."
            embed.add_field(name="쿠왕봇의 선택은...", value=job_choice, inline=False)
            await message.channel.send(embed=embed)                

            
################################ 쿠왕봇 상태보기 ##############################

        if message.content.startswith('!얼마'):
            botNow = time.time()
            h, rem = divmod(botNow-botStart, 3600)
            m, s = divmod(rem, 60)
            embed = discord.Embed(title = "쿠앙봇 정보", color = 0x6d89c1)
            embed.add_field(name = ":timer:", value = "{:0>2}:{:0>2}:{:05.2f}".format(int(h),int(m),s))
            embed.add_field(name = ":desktop:", value = str(infoRPi.getCPUUsage()) + " %", inline = False)
            embed.add_field(name = ":minidisc:", value = str(infoRPi.getMemoryUsage()) + " %", inline = False)
            embed.add_field(name = ":floppy_disk:", value = infoRPi.getRemainDisk(),inline = False)
            embed.add_field(name = ':thermometer:', value = str(round(infoRPi.getCPUtemperature(), 2)) + " ℃", inline = False)
            await message.channel.send(embed=embed)           
        if message.content.startswith('!계산'):
            msg = message.content
            n = msg.replace("!계산 ", "")
            
            try:
                nmsg = numexpr.evaluate(n).item()
                msg_combine = "쿠왕봇의 논리적인 계산에 의하면..답은 " + str(nmsg) + " !!"
            except OverflowError:
                msg_combine = "숫자가 너무 커욧 !!"
                pass
            except SyntaxError:
                msg_combine = "수학 구문을 잘못 입력하셨습니다 !!" 
                pass
            except:
                msg_combine = "숫자를 입력하세욧 !!"
                pass
            
            
            
            await message.channel.send(msg_combine)

            
            
################################ 가위바위보코드 ##############################
          
            
        if message.content.startswith("{0}가위".format(cmd_prefix)) or message.content.startswith("{0}바위".format(cmd_prefix)) or message.content.startswith("{0}보".format(cmd_prefix)):
            file = openpyxl.load_workbook("db/rcp.xlsx")
            sheet = file.active
            i = 1
            rcp_box = ["가위", "바위", "보"]
            rcp = random.choice(rcp_box)            
            while True:
                if sheet["A" + str(i)].value == str(message.author.id): #유저아이디 확인

                    #무승부
                    if cmd == rcp:
                        sheet["D" + str(i)].value = sheet["D" + str(i)].value + 1  #승
                        file.save("db/rcp.xlsx")
                        await message.channel.send("쿠왕봇은 " + rcp + "를 냈습니다. {0.author.mention}님과 무승부\n".format(message) + "(승 : " +str(sheet["B" + str(i)].value) + ", 패 : " + str(sheet["C" + str(i)].value) + ", 무 : " + str(sheet["D" + str(i)].value) + ")")
                        break
                    #승리
                    elif cmd == "가위" and rcp == "보" or cmd == "바위" and rcp == "가위" and cmd == "보" and rcp == "바위": 
                        sheet["B" + str(i)].value = sheet["B" + str(i)].value + 1  #승
                        file.save("db/rcp.xlsx")
                        await message.channel.send("쿠왕봇은 " + rcp + "를 냈습니다. {0.author.mention}님의 승리\n".format(message) + "(승 : " +str(sheet["B" + str(i)].value) + ", 패 : " + str(sheet["C" + str(i)].value) + ", 무 : " + str(sheet["D" + str(i)].value) + ")") 
                        break

                    #패배    
                    elif cmd[0] == "보" and rcp == "가위" or cmd[0] == "가위" and rcp == "바위" and cmd[0] == "바위" and rcp == "보":
                        sheet["C" + str(i)].value = sheet["C" + str(i)].value + 1  #승 
                        file.save("db/rcp.xlsx")                        
                        await message.channel.send("쿠왕봇은 " + rcp + "를 냈습니다. {0.author.mention}님의 패배\n".format(message) + "(승 : " +str(sheet["B" + str(i)].value) + ", 패 : " + str(sheet["C" + str(i)].value) + ", 무 : " + str(sheet["D" + str(i)].value) + ")")  
                        break 
                        
                if sheet["A" + str(i)].value == None: 
                    sheet["A" + str(i)].value = str(message.author.id)
                    # 무승부
                    if cmd == rcp: 
                        sheet["B" + str(i)].value = 0 #승 
                        sheet["C" + str(i)].value = 0 #패 
                        sheet["D" + str(i)].value = 1 #무
                        file.save("db/rcp.xlsx")
                        await message.channel.send("쿠왕봇은 " + rcp + "를 냈습니다. {0.author.mention}님과 무승부\n".format(message) + "(승 : " +str(sheet["B" + str(i)].value) + ", 패 : " + str(sheet["C" + str(i)].value) + ", 무 : " + str(sheet["D" + str(i)].value) + ")")                                   
                        break                    
                    
                    #승리
                    elif cmd == "가위" and rcp == "보" or cmd == "바위" and rcp == "가위" and cmd == "보" and rcp == "바위":
                        sheet["B" + str(i)].value = 1 #승 
                        sheet["C" + str(i)].value = 0 #패 
                        sheet["D" + str(i)].value = 0 #무 
                        file.save("db/rcp.xlsx")
                        await message.channel.send("쿠왕봇은 " + rcp + "를 냈습니다. {0.author.mention}님의 승리\n".format(message) + "(승 : " +str(sheet["B" + str(i)].value) + ", 패 : " + str(sheet["C" + str(i)].value) + ", 무 : " + str(sheet["D" + str(i)].value) + ")")              
                        break                        
                    #패배    
                    elif cmd[0] == "보" and rcp == "가위" or cmd[0] == "가위" and rcp == "바위" and cmd[0] == "바위" and rcp == "보": 
                        sheet["B" + str(i)].value = 0 #승 
                        sheet["C" + str(i)].value = 1 #패 
                        sheet["D" + str(i)].value = 0 #무                  
                        file.save("db/rcp.xlsx")
                        await message.channel.send("쿠왕봇은 " + rcp + "를 냈습니다. {0.author.mention}님의 패배\n".format(message) + "(승 : " +str(sheet["B" + str(i)].value) + ", 패 : " + str(sheet["C" + str(i)].value) + ", 무 : " + str(sheet["D" + str(i)].value) + ")")        
                        
                        break                                         
                i = i + 1
            
################################ 로또 ############################## 

        if message.content.startswith('!로또'):
            msg = message.content
            n = msg.replace("!로또 ", "")
            
            try:
                if int(n) <= 5:
                    for i in range(0, int(n)):
                        lotto = random.sample(range(1, 46), 6)
                        lotto.sort()
                        msg = ', '.join(map(str, lotto))
                        await message.channel.send('{0.author.mention}님을 위한 쿠왕봇의 번호는...'.format(message) + msg)
                elif int(n) > 5:
                    await message.channel.send('{0.author.mention}님을 위한 도박중독 신고 1366'.format(message))
            except ValueError:  
                lotto = random.sample(range(1, 46), 6)
                lotto.sort()
                msg = ', '.join(map(str, lotto))
                await message.channel.send('{0.author.mention}님을 위한 쿠왕봇의 번호는...'.format(message) + msg)
      

    
    
################################ 봇 실행 ##############################
client.run(config.discord["TOKEN"])
